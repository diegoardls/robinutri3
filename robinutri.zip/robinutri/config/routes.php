<?php
// Cargar configuración de base de datos
require_once 'database.php';

// Cargar modelos
require_once '../app/models/Database.php';
require_once '../app/models/ChatModel.php';
require_once '../app/models/ProfileModel.php';


?>
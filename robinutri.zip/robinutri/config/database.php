<?php
// app/config/database.php
define('DB_HOST', 'b4glny4rnuw9w6q9jkqy-mysql.services.clever-cloud.com');
define('DB_NAME', 'b4glny4rnuw9w6q9jkqy');
define('DB_USER', 'ukmqtsabpf040r8y');
define('DB_PASS', 'JicCmXLlbNs8oxoG7VIi');
define('DB_CHARSET', 'mysql://ukmqtsabpf040r8y:JicCmXLlbNs8oxoG7VIi@b4glny4rnuw9w6q9jkqy-mysql.services.clever-cloud.com:3306/b4glny4rnuw9w6q9jkqy');
?>